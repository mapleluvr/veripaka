# Veripaka

A Pi-first project for exploring how real software should be tested, developing useful test recipes, and reusing them under the right conditions. The current alpha implements the execution and reuse foundation—not general autonomous strategy discovery.

The CLI currently freezes an explicit scope, runs the existing Node test runner, and maps managed evidence to required claims. It does not verify every user goal or defend against a malicious writer with the same OS permissions.

Docs: [current and archived documents](docs/README.md). Design: [combined design](docs/VERIPAKA_DESIGN.md). Scope: [implementation phases](docs/IMPLEMENTATION_PHASES.md). The scoped S1 evidence checkpoint is complete; this remains a private/unpublished internal alpha, not a broadly qualified release.

## Development

Requires Node 24 and npm. Windows is the initial test platform; other platforms are not yet qualified.

```text
npm install
npm run typecheck
npm test
```

## Local reference project

After building, from this repository root:

```text
node dist/src/cli/main.js --project examples/backend recipe lint --json
node dist/src/cli/main.js --project examples/backend find settings --json
node dist/src/cli/main.js --project examples/backend apply backend --input verification-input.json --json
node dist/src/cli/main.js --project examples/backend run <returned-run-id> --json
```

The reference application's tests use real HTTP requests and file persistence with private temporary directories. A run requires one explicit, enabled Node-test command binding. Claim identity is a declared test file plus a unique top-level test name. Nested tests/suites, arbitrary shell bindings, deployed subjects, guided execution and investigation execution are not supported in S1.

`run cancel <id>` requests cooperative cancellation, including on Windows, without taking the execution lock away from its owner. It returns exit 3 and `cancellation-requested`, not a completion verdict. Wait for the original `run` result and inspect `execution.json` cleanup; a racing completed run may already have finished. Prepared or terminal runs reject cancellation. Do not use Windows `process.kill`/Task Manager as a substitute for cooperative cancellation: forced termination can leave an inspect-before-recovery lock.

`run` normally captures and finalizes automatically. `run <id> --capture-only` is a lower-level recovery/testing path: it returns exit 3 and `captured-not-finalized`, never a passing verdict. Complete it using `run finalize <id>`. `run collect` accepts observations but cannot upgrade a caller-supplied JSON object to executable evidence.

JSON stdout has `schema`, `ok`, `command`, and `data` or `error`. Inspect `data.verdict`, `verdictBasis`, check results and goals. A management command's exit 0 only means that operation completed. A verification exits 0 for scoped pass, 1 for a valid required assertion failure, 2 for invalid input and 3 for incomplete/unsupported evaluation.

## Pi

The package declares a Skill and a relative launcher, without extensions or a global CLI dependency. Test an actual tarball installation in a separate local consumer before claiming installation works.

For new implementation E2E model sessions, the operator specifies this sole model:

```text
pi --model Mapleluv-ChatCompletions/deepseek-flash:max --no-extensions --no-session --print <task>
```

Do not add `-e` or fall back to a different model. Retry upstream access/transport failures with recorded attempts and appropriate backoff; retain failed or partial samples and verify cleanup before replaying side effects. A behavioral failure is not a transport retry. An explicit installed `--skill <path>` may be combined with `--no-skills` to isolate the tested Skill. Model credentials remain in the user's existing provider configuration, not in this repository.

Historical S1 evidence used `:high` and is unchanged. `scripts/pi-smoke.mjs <consumer> <pi-cli.js> <label> [task-file]` now uses `:max` and creates a unique attempt directory per invocation. Omit `task-file` for the original cold-reuse task; provide it for a bounded exploration/capability task, including its permitted actions. The harness retains raw events, errors and frozen prompt/Skill bytes; its completion status only requests review, never certifies test quality. It does not automatically replay attempts.

The separately requested design reviewer uses its configured reviewer profile; it is not an implementation E2E model session.

## Boundaries and recovery

- Methods live in `docs/verification`; high-frequency run material lives in ignored `.veripaka/runs`.
- Source/recipe/input drift requires a new plan. Reusing a terminal result checks current integrity instead of silently accepting changed evidence.
- Same-project execution is mutually exclusive. Inspect `.veripaka/locks/execution/owner.json` and the owned processes before recovering a stale lock. The CLI does not steal locks based on age.
- Cancellation manages the owned process tree. Unknown cleanup retains the lock and does not pass. There is no cross-project shared-resource scheduler or OS sandbox.
- Snapshot roots are an explicit declaration, not automatic dependency analysis. Qualification must establish the actual source-to-service relationship. S1 does not prove arbitrary endpoints run the current checkout.
- `trial` recipes do not become `reusable` because one run passes. Good/bad-object and cold-context records are separate qualifications.

See [S1 checkpoint](docs/implementation/S1_EVIDENCE_CHECKPOINT.md) for what has actually been executed, rather than treating this README as an acceptance report.
